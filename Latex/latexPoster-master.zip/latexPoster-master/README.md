# latexPoster
LaTex海报模板存档

## 使用Step
云端使用：使用[overleaf](https://www.overleaf.com/),将项目下载的zip压缩包以upload project的模式上传project，然后进入项目中，点击左上角的Menu，将Compiler选项选择XeLeTex支持中文，即可正常使用。

本地使用：使用TexStudio编译即可。

文档注释在poster.tex文件中

## 样例 Example
[Poster](https://github.com/yanbo01haomiao/latexPoster/blob/master/poster.pdf)
